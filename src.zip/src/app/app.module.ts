import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { DisplayComponent } from './display/display.component';
import { AddComponent } from './add/add.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ImagesComponent } from './assets/images/images.component';
import { HtComponent } from './add/html/ht/ht.component';
import { Ht1Component } from './add/html1/ht1/ht1.component';
import { Ht2Component } from './add/html/ht2/ht2.component';

@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    AddComponent,
    DashboardComponent,
    ImagesComponent,
    HtComponent,
    Ht1Component,
    Ht2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
